// [{pcid:xx,
//     source:xx, destination:xx, content:xx,
//     sendtime: xx},
//     {pcid:xx,
//     source:xx, destination:xx, content:xx,
//     sendtime: xx},...]
export async function fetchChatHistory(uid, friendUid) {
  return fetch(
    "http://localhost:8181/api/chat/friendchat/" + uid + "/" + friendUid,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    }
  ).then((data) => data.json());
}

export async function fetchGroupChatHistory(gid) {
  return fetch("http://localhost:8181/api/chat/groupchat/" + gid, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  }).then((data) => data.json());
}

export async function postMessage(info) {
  return fetch("http://localhost:8181/api/chat/friendchat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

export async function postGroupMessage(info) {
  return fetch("http://localhost:8181/api/chat/groupchat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

export async function fetchBalanceSummary(info) {
  return fetch("http://localhost:8181/api/balance", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

export async function uidToUsername(uid) {
  return fetch("http://localhost:8181/api/username/" + uid, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  }).then((data) => data.json());
}

export async function fetchTotalBalance(uid) {
  return fetch("http://localhost:8181/api/balance/" + uid, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  }).then((data) => data.json());
}
