import React, { useState, useEffect } from "react";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  Chip,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {
  fetchChatHistory,
  postMessage,
  postGroupMessage,
  fetchBalanceSummary,
  fetchGroupChatHistory,
  uidToUsername,
} from "./asyncHelperFunc";
import "./ChatPanel.css";

const capitalizeFirstLetter = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

const getName = (firstName, lastName) => {
  return (
    capitalizeFirstLetter(firstName) + " " + capitalizeFirstLetter(lastName)
  );
};

const ChatPanel = ({
  uid,
  friend,
  group,
  transactions,
  dialogOpen,
  groupMode,
}) => {
  const [chatHistory, setChatHistory] = useState([]);
  const [messageInput, setMessageInput] = useState("");
  const [expandAccordion, setExpandAccordion] = useState(false);
  const [transactionSummary, setTransactionSummary] = useState([]);
  useEffect(() => {
    if (groupMode) {
      getGroupChatHistory();
    } else {
      getChatHistory();
      getBalanceSummary();
    }
  }, [friend, group, dialogOpen, groupMode]);

  let oweAdded = false;
  let reqAdded = false;

  const getChatHistory = async () => {
    const response = await fetchChatHistory(uid, friend.uid);
    setChatHistory(response);
  };

  const getGroupChatHistory = async () => {
    const response = await fetchGroupChatHistory(group.gid);
    setChatHistory(response);
  };

  const getBalanceSummary = async () => {
    const response = await fetchBalanceSummary({
      source: uid,
      destination: friend.uid,
    });
    response.sort(sortBalanceSummary);
    setTransactionSummary(response);
  };

  const sortBalanceSummary = (a, b) => {
    return a[1] - b[1];
  };

  const switchOweAdded = () => {
    if (!oweAdded) oweAdded = true;
  };

  const switchReqAdded = () => {
    if (!reqAdded) reqAdded = true;
  };

  const sendMessage = async () => {
    //uid, friend, messageInput
    const response = await postMessage({
      source: uid,
      destination: friend.uid,
      content: messageInput,
    });
    getChatHistory();
  };

  const sendGroupMessage = async () => {
    const response = await postGroupMessage({
      gid: group.gid,
      uid: uid,
      content: messageInput,
    });
    getGroupChatHistory();
  };

  const inputChange = (e) => {
    setMessageInput(e.target.value);
  };
  const accordionExpand = (e, expanded) => {
    setExpandAccordion(expanded);
  };
  return (
    <div className="chatContainer">
      <Accordion onChange={accordionExpand}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          {console.log(group, friend, groupMode)}
          {groupMode ? (
            <Typography>{group.groupname}</Typography>
          ) : (
            <Typography>
              {getName(friend.firstname, friend.lastname)}
            </Typography>
          )}
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            {!transactionSummary || transactionSummary.length === 0 ? (
              "No pending transaction"
            ) : (
              <React.Fragment>
                {transactionSummary.map((balance) => (
                  <React.Fragment>
                    {balance[1] < 0 ? (
                      <>
                        {oweAdded
                          ? ", " + Math.abs(balance[1]) + " " + balance[0]
                          : getName(friend.firstname, friend.lastname) +
                            " requested you to pay " +
                            balance[1] +
                            " " +
                            balance[0]}
                        {switchOweAdded()}
                      </>
                    ) : (
                      <>
                        {reqAdded
                          ? ", " + Math.abs(balance[1]) + " " + balance[0]
                          : (oweAdded ? "; " : "") +
                            getName(friend.firstname, friend.lastname) +
                            " owes you " +
                            balance[1] +
                            " " +
                            balance[0]}
                        {switchReqAdded()}
                      </>
                    )}
                  </React.Fragment>
                ))}
              </React.Fragment>
            )}
          </Typography>
        </AccordionDetails>
      </Accordion>
      <div
        className={
          expandAccordion ? "chatHistoryExpanded" : "chatHistoryCollapsed"
        }
      >
        {chatHistory ? (
          <div className="messageContainer">
            {chatHistory
              .slice(0)
              .reverse()
              .map((message) => (
                <div
                  key={message.fcid}
                  className={
                    message.source === uid || message.uid === uid
                      ? "rightMessage"
                      : "leftMessage"
                  }
                >
                  <Typography variant="caption" display="block" gutterBottom>
                    {groupMode ? capitalizeFirstLetter(message.username) + " " + message.sendtime : message.sendtime}
                  </Typography>
                  {message.source === uid || message.uid === uid ? (
                    <Chip color="success" label={message.content} />
                  ) : (
                    <Chip label={message.content}></Chip>
                  )}
                </div>
              ))}
          </div>
        ) : (
          <React.Fragment></React.Fragment>
        )}
      </div>
      <div className="message">
        <div className="messageInput">
          <TextField
            label="Message"
            variant="standard"
            focused
            onChange={inputChange}
            fullWidth={true}
          />
        </div>
        <Button
          variant="outlined"
          onClick={groupMode ? sendGroupMessage : sendMessage}
        >
          Send
        </Button>
      </div>
    </div>
  );
};

export default ChatPanel;
