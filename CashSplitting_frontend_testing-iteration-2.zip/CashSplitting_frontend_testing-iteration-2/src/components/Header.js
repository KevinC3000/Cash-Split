import { AppBar, Box, Button, Toolbar } from "@mui/material";
import GitHubIcon from "@mui/icons-material/GitHub";
import React from "react";
import "./Header.css";

const Header = () => {
  return(
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" color="transparent">
        <Toolbar className="appBar">
          <h2 className="title">Cashsplitting Portal</h2>
          <Box className="references">
            <a href="https://github.com/KevinC3000/Cash-Splitting-frontend">
              <button className="button">
                <GitHubIcon />
              </button>
            </a>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
    
  );
};

export default Header;