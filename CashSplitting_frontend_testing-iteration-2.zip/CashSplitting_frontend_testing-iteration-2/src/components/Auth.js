import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import TextField from "@mui/material/TextField";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import Header from "./Header";
import "./Auth.css";

const theme = makeStyles({
  textField: {
    marginBottom: "25px !important",
  },
});

async function signupUser(credentials) {
  return fetch("http://localhost:8181/api/signup/user", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(credentials),
  }).then((data) => data.json());
}

async function signupPassword(credentials) {
  return fetch("http://localhost:8181/api/signup/password", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(credentials),
  }).then((data) => data.json());
}

async function loginUser(credentials) {
  return fetch("http://localhost:8181/api/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(credentials),
  }).then((data) => data.json());
}

const Auth = ({ setToken, setUserID }) => {
  const [username, setUsername] = useState(undefined);
  const [password, setPassword] = useState(undefined);
  const [confirmed, setConfirmed] = useState(undefined);
  const [email, setEmail] = useState("undefined");
  const [firstName, setFirstName] = useState(undefined);
  const [lastName, setLastName] = useState(undefined);
  const [dialogOpen, setDialog] = useState(false);
  const [dialogTitle, setDialogTitle] = useState("");
  const [dialogContent, setDialogContent] = useState("");
  const [status, setStatus] = useState("login");

  const handleChange = (event, newValue) => {
    setStatus(newValue);
  };

  const handleLogin = async () => {
    const response = await loginUser({
      username: username,
      password: password,
    });
    if (response.Success === false) {
      setDialogTitle("Alert");
      setDialogContent("Incorrect username and password");
      setDialog(true);
    }
    setToken(response.token);
    setUserID(response.uid);
  };

  const handleSignup = async () => {
    if (confirmed !== password) {
      setDialogTitle("Alert");
      setDialogContent("Unmached password!");
      setDialog(true);
    } else {
      const responseUser = await signupUser({
        username: username,
        lastname: lastName,
        firstname: firstName,
        email: email,
      });
      const responsePassword = await signupPassword({
        uid: responseUser.uid,
        password: password,
      });
      if (responseUser && responsePassword === true) {
        setDialogTitle("Congrats!");
        setDialogContent("You are all set!");
        setDialog(true);
        setStatus("login");
      } else {
        setDialogTitle("Error");
        setDialogContent(
          "This username has already been used, please choose another one."
        );
        setDialog(true);
      }
    }
  };

  const classes = theme();

  return (
    <div>
      <Header />
      <div className="container">
        <Box className="auth-box" noValidate autoComplete="off">
          <TabContext value={status}>
            <Box
              sx={{
                borderBottom: 1,
                borderColor: "divider",
                width: 400,
                marginTop: "10%",
              }}
            >
              <TabList
                onChange={handleChange}
                aria-label="change-bar"
                variant="fullWidth"
                centered
              >
                <Tab label="SIGN IN" value="login" />
                <Tab label="SIGN UP" value="signup" />
              </TabList>
            </Box>
            <TabPanel value="login">
              <Box
                component="form"
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  marginTop: "10%",
                  width: 300,
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  className={classes.textField}
                  required
                  id="Username"
                  label="Username"
                  onChange={(e) => setUsername(e.target.value)}
                  fullWidth
                />
                <TextField
                  className={classes.textField}
                  id="Password"
                  label="Password"
                  type="password"
                  autoComplete="current-password"
                  required
                  onChange={(e) => setPassword(e.target.value)}
                  fullWidth
                />
                <Button variant="outlined" onClick={handleLogin}>
                  Login
                </Button>
              </Box>
            </TabPanel>
            <TabPanel value="signup">
              <Box
                component="form"
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  marginTop: "10%",
                  width: 300,
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  className={classes.textField}
                  required
                  id="Username"
                  label="Username"
                  onChange={(e) => setUsername(e.target.value)}
                  fullWidth
                />
                <TextField
                  className={classes.textField}
                  required
                  id="Password"
                  label="Password"
                  type="password"
                  autoComplete="current-password"
                  onChange={(e) => setPassword(e.target.value)}
                  fullWidth
                />
                {confirmed === password ? (
                  <TextField
                    className={classes.textField}
                    required
                    id="confirmPassword"
                    label="Confirm Password"
                    type="password"
                    onChange={(e) => setConfirmed(e.target.value)}
                    fullWidth
                  />
                ) : (
                  <TextField
                    className={classes.textField}
                    required
                    id="confirmPassword"
                    label="Confirm Password"
                    type="password"
                    error
                    onChange={(e) => setConfirmed(e.target.value)}
                    fullWidth
                  />
                )}
                <TextField
                  className={classes.textField}
                  required
                  id="firstName"
                  label="First Name"
                  onChange={(e) => setFirstName(e.target.value)}
                  fullWidth
                />
                <TextField
                  className={classes.textField}
                  required
                  id="lastName"
                  label="Last Name"
                  onChange={(e) => setLastName(e.target.value)}
                  fullWidth
                />
                <TextField
                  className={classes.textField}
                  id="email"
                  label="Email"
                  onChange={(e) => setEmail(e.target.value)}
                  fullWidth
                />
                <Button variant="outlined" onClick={handleSignup}>
                  Signup
                </Button>
              </Box>
            </TabPanel>
          </TabContext>
        </Box>
      </div>
      <Dialog open={dialogOpen} onClose={() => setDialog(false)}>
        <DialogTitle id="dialog-title">{dialogTitle}</DialogTitle>
        <DialogContent>
          <DialogContentText>{dialogContent}</DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Auth;
