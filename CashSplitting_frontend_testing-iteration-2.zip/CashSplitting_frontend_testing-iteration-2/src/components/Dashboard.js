import React, { useState, useEffect } from "react";
import { AppBar, Avatar, Box, Button, Toolbar } from "@mui/material";
import AccountCircle from "@mui/icons-material/AccountCircle";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import SearchIcon from "@mui/icons-material/Search";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  Divider,
  FormControl,
  Badge,
  Paper,
  TextField,
  IconButton,
  Input,
  InputAdornment,
  InputBase,
  InputLabel,
  Select,
  Tab,
  Typography,
  MenuItem,
  Menu,
} from "@mui/material";
import PopupState, { bindTrigger, bindMenu } from "material-ui-popup-state";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import Header from "./Header";
import { styled } from "@mui/material/styles";
import GroupAddIcon from "@mui/icons-material/GroupAdd";
import "./Dashboard.css";
import ChatPanel from "./ChatPanel";
import { fetchTotalBalance } from "./asyncHelperFunc";

const StyledBadge = styled(Badge)(({ theme }) => ({
  "& .MuiBadge-badge": {
    right: -3,
    top: 13,
    border: `2px solid ${theme.palette.background.paper}`,
    padding: "0 4px",
  },
}));

async function createGroup(info) {
  return fetch("http://localhost:8181/api/group", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

async function updateRequest(info) {
  return fetch("http://localhost:8181/api/friendApp/update", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

async function getUidByUsername(username) {
  return fetch("http://localhost:8181/api/uid/" + username, {
    method: "GET",
  }).then((data) => data.json());
}

// async function getUsernameByUid(uid) {
//   return fetch("http://localhost:8181/api/username/" + uid, {
//     method: "GET",
//   }).then((data) => data.text());
// }

async function addFriendRequest(info) {
  return fetch("http://localhost:8181/api/newFriendApp", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

async function quitGroup(gid, uid) {
  return fetch("http://localhost:8181/api/group/quit/" + gid + "/" + uid, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(),
  }).then((data) => data.json());
}

async function addToGroup(gid, uid) {
  return fetch("http://localhost:8181/api/group/add/" + gid + "/" + uid, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(),
  }).then((data) => data.json());
}

async function getFriendsList(uid) {
  return fetch("http://localhost:8181/api/" + uid + "/friend", {
    method: "GET",
  }).then((data) => data.json());
}

async function payTransaction(tid) {
  return fetch("http://localhost:8181/api/transaction/" + tid, {
    method: "GET",
  }).then((data) => data.json());
}

async function getFriendsApplicationList(uid) {
  return fetch("http://localhost:8181/api/" + uid + "/friendApp", {
    method: "GET",
  }).then((data) => data.json());
}

async function getGroupList(uid) {
  return fetch("http://localhost:8181/api/group/listGroup/" + uid, {
    method: "GET",
  }).then((data) => data.json());
}

async function deleteFriend(info) {
  return fetch("http://localhost:8181/api/friend/update", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

async function createTransaction(info) {
  return fetch("http://localhost:8181/api/transaction/individual", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  }).then((data) => data.json());
}

async function showAllTransaction(uid) {
  return fetch("http://localhost:8181/api/transaction/user/" + uid, {
    method: "GET",
  }).then((data) => data.json());
}

async function showFaq() {
  return fetch("http://localhost:8181/api/faq", {
    method: "GET",
  }).then((data) => data.json());
}

const Dashboard = ({ uid, setToken }) => {
  const [value, setValue] = useState("1");
  const [anchorEl, setAnchorEl] = useState(null);
  const [dialogOpen, setDialog] = useState(false);
  const [dialogTitle, setDialogTitle] = useState("");
  const [dialogContent, setDialogContent] = useState("");
  const [friendsList, setFriendsList] = useState(null);
  const [applicationList, setApplicationList] = useState(null);
  const [groupList, setGroupList] = useState(null);
  const [allTransactionList, setAllTransactionList] = useState(null);
  const [faqList, setFaqList] = useState(null);
  const [friendSelected, setFriendSelected] = useState(false);
  const [friendDetails, setFriendDetails] = useState(null);
  const [transactions, setTransActions] = useState(null);
  const [groupSelected, setGroupSelected] = useState(false);
  const [groupDetails, setGroupDetails] = useState(null);
  const [totalBalance, setTotalBalance] = useState([]);

  let groupname = "";
  let usernameInput = "";
  let tmpAmount = 0.0;
  let realAmount = 0.0;
  let tmpCurrency = "USD";
  let transactionComment = "";
  let strAmount = "";
  let strProportion = "";
  let valid = undefined;
  let tmpMethod = 1;
  let proportion = 50;

  useEffect(() => {
    if (uid) {
      getFriends(uid);
      getFriendsApplication(uid);
      getGroups(uid);
      getAllTransaction(uid);
      getTotalBalance(uid);
    }
  }, [uid, dialogOpen]);
  const handleMethodChange = (event) => {
    tmpMethod = event.target.value;
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleLogout = () => {
    setToken("");
  };

  const tmpHandler = () => {
    setAnchorEl(null);
  };

  const pendingApplication = () => {
    setDialog(true);
    setDialogTitle("Pending Friend Requests");
    setDialogContent(
      <div>
        {applicationList.map((application) => (
          <div key={application.aid}>
            {application.source === uid ? (
              <React.Fragment>
                <span>
                  You have sent request to {application.destinationName}
                </span>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <span>{application.sourceName} sent a request to you</span>
                <Button
                  size="small"
                  variant="outlined"
                  className="acceptButton"
                  onClick={() =>
                    updateFriendRequest(
                      application.aid,
                      application.source,
                      application.destination,
                      "approved"
                    )
                  }
                >
                  Accept
                </Button>
                <Button
                  size="small"
                  color="success"
                  variant="outlined"
                  onClick={() =>
                    updateFriendRequest(
                      application.aid,
                      application.source,
                      application.destination,
                      "denied"
                    )
                  }
                >
                  Reject
                </Button>
              </React.Fragment>
            )}
          </div>
        ))}
      </div>
    );
  };

  const userNameInputHandler = async () => {
    const targetUsername = await getUidByUsername(usernameInput);
    if (uid === targetUsername) {
      setDialog(true);
      setDialogTitle("Request Failed");
      setDialogContent(
        <React.Fragment>
          You can't send friend request to yourself.
        </React.Fragment>
      );
    } else {
      const response = await addFriendRequest({
        source: uid,
        destination: targetUsername,
      });
      if (response === true) {
        setDialog(true);
        setDialogTitle("Friend Request Sent");
        setDialogContent(
          <React.Fragment>
            Please wait until the request is accepted.
          </React.Fragment>
        );
      } else {
        setDialog(true);
        setDialogTitle("Request Failed");
        setDialogContent(
          <React.Fragment>
            You have already sent this request/added this user or this user is
            not existed, please wait or correct your input.
          </React.Fragment>
        );
      }
    }
  };

  const updateFriendRequest = async (aid, src, dest, status) => {
    const response = await updateRequest({
      aid: aid,
      source: src,
      destination: dest,
      status: status,
    });
    if (response) {
      setDialog(true);
      setDialogTitle("Request Processed");
      setDialogContent(<React.Fragment>You're all set!</React.Fragment>);
    }
  };

  const getTotalBalance = async (uid) => {
    const response = await fetchTotalBalance(uid);
    setTotalBalance(response);
  };
  const getFriends = async (uid) => {
    const friendsList = await getFriendsList(uid);
    setFriendsList(friendsList);
  };

  const getGroups = async (uid) => {
    const groupList = await getGroupList(uid);
    setGroupList(groupList);
  };

  const getFriendsApplication = async (uid) => {
    const applicationList = await getFriendsApplicationList(uid);
    // TODO username
    setApplicationList(applicationList);
  };

  const getAllTransaction = async (uid) => {
    const allTransactionList = await showAllTransaction(uid);
    setAllTransactionList(allTransactionList);
  };

  const handleAddGroup = (uid) => {
    setDialog(true);
    setDialogTitle("Create a Group - Select Group Members");
    setDialogContent(
      <React.Fragment>
        <div className="groupName">
          <TextField
            sx={{ marginTop: "10px", marginBottom: "10px", width: 300 }}
            required
            id="Groupname"
            label="Your Group Name"
            onChange={(e) => (groupname = e.target.value)}
          />
        </div>
        <div className="finishButton">
          <Button
            variant="outlined"
            onClick={() => handleCreateGroup(uid, groupname)}
          >
            Finish
          </Button>
        </div>
      </React.Fragment>
    );
  };

  const handleCreateGroup = async (uid, groupname) => {
    const response = await createGroup({
      uid: uid,
      groupname: groupname,
    });
    if (response === true) {
      setDialogTitle("Congrats!");
      setDialogContent("You have successfully created a group");
      setDialog(true);
    } else {
      setDialog(true);
      setDialogTitle("Error");
      setDialogContent(
        "Something went wrong, aliens stole the group you created"
      );
    }
  };

  const handleCheckQuit = (gid, uid, quitGroupName) => {
    setDialog(true);
    setDialogTitle("Confirm");
    setDialogContent(
      <React.Fragment>
        <div className="checkQuit">
          <Typography variant="h5" gutterBottom component="div">
            Are you sure you want to quit {quitGroupName}?
          </Typography>
        </div>
        <div className="quitBtn">
          <Button
            variant="contained"
            sx={{ width: 120 }}
            onClick={() => handleQuit(gid, uid)}
          >
            Quit
          </Button>
        </div>
      </React.Fragment>
    );
  };

  const handleQuit = async (gid, uid) => {
    const response = await quitGroup(gid, uid);
    if (response === true) {
      setDialogTitle("Congrats!");
      setDialogContent("You have successfully quited the group!");
      setDialog(true);
    } else {
      setDialog(true);
      setDialogTitle("You are not a member");
      setDialogContent("Cannot quit from this group");
    }
  };

  const handleFinishInvite = async (fuid, gid) => {
    const response = await addToGroup(gid, fuid);
    if (response === true) {
      setDialogTitle("Congrats!");
      setDialogContent("Successfully invite your friend to the group!");
      setDialog(true);
    } else {
      setDialog(true);
      setDialogTitle("Your friend is already in this group");
      setDialogContent("Do not need to invite again");
    }
  };

  const handleFriendInvite = async (
    firstname,
    lastname,
    fuid,
    groupname,
    gid
  ) => {
    setDialog(true);
    setDialogTitle("Confirm");
    setDialogContent(
      <React.Fragment>
        <Typography variant="h5" gutterBottom component="div">
          Invite {firstname + " " + lastname} to {groupname}?
        </Typography>
        <Button
          variant="contained"
          onClick={() => handleFinishInvite(fuid, gid)}
        >
          Invite
        </Button>
      </React.Fragment>
    );
  };

  const handleConfirmDelete = async (uid, fid) => {
    const response = await deleteFriend({
      friend_id: fid,
      uid: uid,
      status: "invalid",
    });
    if (response === "nothing changed") {
      setDialogTitle("Delete fail");
      setDialogContent("This user is not your friend!");
      setDialog(true);
    } else {
      setDialog(true);
      setDialogTitle("Delete complete");
      setDialogContent(response.result);
    }
  };

  const handleDelete = async (uid, fid, firstname, lastname) => {
    setDialog(true);
    setDialogTitle("Confirm");
    setDialogContent(
      <React.Fragment>
        <Typography variant="h5" gutterBottom component="div">
          Delete {firstname + " " + lastname} from your friend list?
        </Typography>
        <div className="confirmDeleteBtn">
          <Button
            variant="outlined"
            color="error"
            onClick={() => handleConfirmDelete(uid, fid)}
          >
            Delete
          </Button>
        </div>
      </React.Fragment>
    );
  };

  const handleCreateTransaction = async (uid, friendInfo) => {
    setDialog(true);
    setDialogTitle("Request a payment");
    setDialogContent(
      <React.Fragment>
        <div className="transactionForm">
          <div className="transactionTitle">
            <Typography variant="h6" gutterBottom component="div">
              Sending request to:{" "}
              {friendInfo.firstname + " " + friendInfo.lastname}
            </Typography>
          </div>
          <div className="amount">
            <Box>
              <TextField
                sx={{ marginTop: "10px", marginBottom: "10px", width: 150 }}
                required
                id="transactionAmount"
                label="Total amount of bill"
                defaultValue={tmpAmount}
                variant="filled"
                onChange={(e) => (tmpAmount = e.target.value)}
              />
              <FormControl
                sx={{
                  marginTop: "10px",
                  marginBottom: "10px",
                  marginLeft: "10px",
                  minWidth: 80,
                }}
              >
                <InputLabel id="simple-select-autowidth-label">
                  Currency
                </InputLabel>
                <Select
                  labelId="simple-select-autowidth-label"
                  id="select-autowidth"
                  defaultValue={tmpCurrency}
                  onChange={(e) => {
                    tmpCurrency = e.target.value;
                  }}
                  autoWidth
                  label="currency"
                >
                  <MenuItem value="USD">USD</MenuItem>
                  <MenuItem value="CNY">CNY</MenuItem>
                  <MenuItem value="EUR">EUR</MenuItem>
                  <MenuItem value="JPY">JPY</MenuItem>
                  <MenuItem value="GBP">GBP</MenuItem>
                  <MenuItem value="SGD">SGD</MenuItem>
                  <MenuItem value="CAD">CAD</MenuItem>
                  <MenuItem value="AUD">AUD</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </div>
          <div className="method">
            <Box>
              <FormControl
                sx={{
                  marginTop: "10px",
                  marginBottom: "10px",
                  marginLeft: "10px",
                  minWidth: 185,
                }}
              >
                <InputLabel id="simple-select-autowidth-label">
                  Method
                </InputLabel>
                <Select
                  labelId="simple-select-autowidth-label"
                  id="select-autowidth"
                  defaultValue={tmpMethod}
                  onChange={handleMethodChange}
                  autoWidth
                  label="method"
                >
                  <MenuItem value={1}>Split Equally</MenuItem>
                  <MenuItem value={0}>Split Proportionally</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </div>
          <div className="comment">
            <FormControl fullWidth sx={{ marginBottom: "10px", minWidth: 500 }}>
              <TextField
                id="transaction_description"
                label="Enter a description"
                fullWidth
                multiline
                rows={4}
                defaultValue=""
                onChange={(e) => (transactionComment = e.target.value)}
              />
            </FormControl>
          </div>
          <div className="transactionRequestBtn">
            <Button
              variant="contained"
              onClick={() =>
                confirmTransaction(
                  uid,
                  friendInfo.uid,
                  tmpAmount,
                  tmpCurrency,
                  transactionComment
                )
              }
            >
              Send Request
            </Button>
          </div>
        </div>
      </React.Fragment>
    );
  };

  const confirmTransaction = async (
    uid,
    fid,
    tmpAmount,
    tmpCurrency,
    transactionComment
  ) => {
    strAmount = tmpAmount + "";
    if (strAmount.indexOf(".") !== -1) {
      valid = strAmount.length - (strAmount.indexOf(".") + 1);
    }
    if (tmpAmount <= 0) {
      setDialog(true);
      setDialogTitle("Incorrect input");
      setDialogContent("Please enter the correct amount!");
    } else if (valid > 2) {
      setDialog(true);
      setDialogTitle("Incorrect input");
      setDialogContent("Please do not enter more than two decimal places!");
    } else {
      setDialog(true);
      setDialogTitle("Confirm");
      setDialogContent(
        <React.Fragment>
          {tmpMethod === 1 ? (
            <Typography variant="h6" gutterBottom component="div">
              Your friend needs to pay 50% of the bill.
            </Typography>
          ) : (
            <React.Fragment>
              <Typography variant="h6" gutterBottom component="div">
                Your friend needs to pay
                <FormControl variant="standard" sx={{ width: "90px" }}>
                  <Input
                    id="standard-adornment-proportion"
                    onChange={(e) => (proportion = e.target.value)}
                    inputProps={{
                      "aria-label": "proportion",
                      style: { textAlign: "center" },
                    }}
                  />
                </FormControl>
                % of the bill.
              </Typography>
            </React.Fragment>
          )}
          <div className="confirmBtn">
            <Button
              variant="outlined"
              onClick={() =>
                handleSubmitTransaction(
                  uid,
                  fid,
                  tmpAmount,
                  tmpCurrency,
                  transactionComment,
                  proportion
                )
              }
            >
              Confirm
            </Button>
          </div>
        </React.Fragment>
      );
    }
  };

  const changeUidintoUsername = (transactionUid) => {
    for (const n in friendsList.friendList) {
      if (friendsList.friendList[n]["uid"] === transactionUid) {
        return (
          friendsList.friendList[n]["firstname"] +
          " " +
          friendsList.friendList[n]["lastname"]
        );
      }
    }
  };

  const handleShowDetails = async (allTransaction, commentChange) => {
    setDialog(true);
    setDialogTitle("Transaction Details");
    setDialogContent(
      <React.Fragment>
        <div className="transactionDetails">
          <Typography variant="h6" gutterBottom component="div">
            <span className="bolder">Create Time:</span>{" "}
            {allTransaction.create_time}
          </Typography>
          {allTransaction.comment === "" ? (
            <React.Fragment>
              <Typography variant="h6" gutterBottom component="div">
                {commentChange === 0 ? (
                  <React.Fragment>
                    <span className="bolder">Create Time:</span> You didn't
                    write any comment for this transaction.
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <span className="bolder">Create Time:</span> Your friend
                    didn't write any comment for this transaction.
                  </React.Fragment>
                )}
              </Typography>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <Typography variant="h6" gutterBottom component="div">
                <span className="bolder">Comments:</span>{" "}
                {allTransaction.comment}
              </Typography>
            </React.Fragment>
          )}
        </div>
      </React.Fragment>
    );
  };

  const handlePayment = async (tid) => {
    const response = await payTransaction(tid);
    if (response === true) {
      setDialogTitle("Congrats!");
      setDialogContent("You have paid successfully!");
      setDialog(true);
    } else {
      console.log("responseafter:" + response);
      console.log("typeofResponseafter:" + typeof response);
      setDialog(true);
      setDialogTitle("Error");
      setDialogContent(
        "Something went wrong. Payment failed. Please try again later!"
      );
    }
  };

  const handlePaymentConfirm = async (allTransaction) => {
    setDialog(true);
    setDialogTitle("Confirm your payment");
    setDialogContent(
      <React.Fragment>
        <div className="paymentConfirmMsg">
          <Typography variant="h6" gutterBottom component="div">
            You are paying{" "}
            <span className="bolder">
              {allTransaction.amount} {allTransaction.currency}
            </span>{" "}
            to {changeUidintoUsername(allTransaction.source)}.
          </Typography>
        </div>
        <div className="paymentConfirmBtn">
          <Button
            variant="outlined"
            onClick={() => handlePayment(allTransaction.tid)}
          >
            Pay now
          </Button>
        </div>
      </React.Fragment>
    );
  };

  const handleShowAllTransaction = async () => {
    setDialog(true);
    setDialogTitle("Transaction history");
    setDialogContent(
      <React.Fragment>
        <div className="transactionHistory">
          <FormControl sx={{ Width: 700, maxHeight: 400 }}>
            {allTransactionList && allTransactionList.length !== 0 ? (
              <div className="transactionContent">
                {allTransactionList.map((allTransaction) => (
                  <React.Fragment>
                    {allTransaction.source === uid ? (
                      <React.Fragment>
                        <Typography variant="h6" gutterBottom component="div">
                          You charged{" "}
                          {changeUidintoUsername(allTransaction.destination)}{" "}
                          for {allTransaction.amount} in{" "}
                          {allTransaction.currency}.
                        </Typography>
                        <div className="optionContainer">
                          <span className="detailsBtn">
                            <Chip
                              label="Details"
                              onClick={() =>
                                handleShowDetails(allTransaction, 0)
                              }
                              icon={<SearchIcon />}
                              color="secondary"
                            />
                          </span>
                          <span className="status">
                            {allTransaction.status === "unpaid" ? (
                              <Chip color="error" label="Unpaid" />
                            ) : (
                              <Chip color="success" label="Paid" />
                            )}
                          </span>
                        </div>
                        <Divider sx={{ marginTop: "10px" }} />
                      </React.Fragment>
                    ) : (
                      <React.Fragment>
                        <Typography variant="h6" gutterBottom component="div">
                          You owe {changeUidintoUsername(allTransaction.source)}{" "}
                          for {allTransaction.amount} in{" "}
                          {allTransaction.currency}.
                        </Typography>
                        <div className="optionContainer">
                          <span className="detailsBtn">
                            <Chip
                              label="Details"
                              onClick={() =>
                                handleShowDetails(allTransaction, 1)
                              }
                              icon={<SearchIcon />}
                              color="secondary"
                            />
                          </span>
                          <span className="status">
                            {allTransaction.status === "unpaid" ? (
                              <React.Fragment>
                                <Chip color="error" label="Unpaid" />
                                <span className="payBtn">
                                  <Chip
                                    label="Pay now"
                                    onClick={() =>
                                      handlePaymentConfirm(allTransaction)
                                    }
                                    icon={<MonetizationOnIcon />}
                                    color="primary"
                                  />
                                </span>
                              </React.Fragment>
                            ) : (
                              <Chip color="success" label="Paid" />
                            )}
                          </span>
                        </div>
                        <Divider sx={{ marginTop: "10px" }} />
                      </React.Fragment>
                    )}
                  </React.Fragment>
                ))}
              </div>
            ) : (
              <>You don't have any transactions yet.</>
            )}
          </FormControl>
        </div>
      </React.Fragment>
    );
  };

  const viewTotalBalance = () => {
    setDialog(true);
    setDialogTitle("Total Balance");
    setDialogContent(
      <React.Fragment>
        {totalBalance ? (
          <React.Fragment>
            {totalBalance.length === 0 ? (
              "You're all clear!"
            ) : (
              <React.Fragment>
                {totalBalance.map((currency) => (
                  <div key={currency[0]}>
                    {currency[1] > 0
                      ? "Others owe you " + Math.abs(currency[1]) + " " + currency[0]
                      : "You owe others " + Math.abs(currency[1]) + " " + currency[0]}
                  </div>
                ))}
              </React.Fragment>
            )}
          </React.Fragment>
        ) : (
          <></>
        )}
      </React.Fragment>
    );
  };
  const handleFAQ = async () => {
    const faqList = await showFaq();
    setFaqList(faqList);
    setDialog(true);
    setDialogTitle("Cashsplitting Helpdesk");
    setDialogContent(
      <React.Fragment>
        {faqList ? (
          <React.Fragment>
            {faqList.map((faq) => (
              <div className="faqSection" key={faq.question}>
                <Typography variant="h6">
                  <p className="question">{faq.question}</p>
                  <p className="answer">{faq.answer}</p>
                </Typography>
              </div>
            ))}
          </React.Fragment>
        ) : (
          <React.Fragment></React.Fragment>
        )}
      </React.Fragment>
    );
  };

  const handleSubmitTransaction = async (
    uid,
    fid,
    tmpAmount,
    tmpCurrency,
    transactionComment,
    proportion
  ) => {
    strProportion = proportion + "";
    if (strProportion.indexOf(".") !== -1) {
      valid = strProportion.length - (strProportion.indexOf(".") + 1);
    }
    if (proportion <= 0 || proportion > 100) {
      setDialog(true);
      setDialogTitle("Incorrect input");
      setDialogContent("Please enter the correct proportion!");
    } else if (valid > 2) {
      setDialog(true);
      setDialogTitle("Incorrect input");
      setDialogContent("Please do not enter more than two decimal places!");
    } else {
      realAmount = (tmpAmount / 100) * proportion;
      //keep the following lines for testing
      // console.log("realAmountBefore"+realAmount);
      realAmount = realAmount.toFixed(2);
      // console.log("proportion"+proportion);
      // console.log("realAmount"+realAmount);
      const response = await createTransaction({
        source: uid,
        destination: fid,
        currency: tmpCurrency,
        amount: realAmount,
        comment: transactionComment,
      });
      if (response === true) {
        setDialogTitle("Congrats!");
        setDialogContent(
          "Your payment request is sent. You charged " +
            realAmount +
            " " +
            tmpCurrency +
            "."
        );
        setDialog(true);
      } else {
        setDialog(true);
        setDialogTitle("Error");
        setDialogContent("Sending failed, please try again later.");
      }
    }
  };

  const handleInvite = async (uid, groupname, gid) => {
    setDialog(true);
    setDialogTitle("Select friends to invite");
    setDialogContent(
      <React.Fragment>
        <div className="friendsList">
          {friendsList &&
          friendsList.friendList &&
          friendsList.friendList.length !== 0 ? (
            <div className="friend">
              {friendsList.friendList.map((friend) => (
                <React.Fragment>
                  <Stack direction="row" spacing={1}>
                    <Chip
                      avatar={
                        <Avatar>
                          {friend.firstname[0]}
                          {friend.lastname[0]}
                        </Avatar>
                      }
                      label={friend.firstname + " " + friend.lastname}
                      variant="outlined"
                      onClick={() =>
                        handleFriendInvite(
                          friend.firstname,
                          friend.lastname,
                          friend.uid,
                          groupname,
                          gid
                        )
                      }
                    />
                  </Stack>
                </React.Fragment>
              ))}
            </div>
          ) : (
            <>You haven't added any friends yet.</>
          )}
        </div>
      </React.Fragment>
    );
  };
  const handleViewHistory = (uid, fid) => {
    setDialog(true);
    setDialogTitle("Transaction history");
    setDialogContent(
      <React.Fragment>
        <div className="transactionHistory">
          <FormControl sx={{ Width: 700, maxHeight: 400 }}>
            {allTransactionList && allTransactionList.length !== 0 ? (
              <div className="transactionContent">
                {allTransactionList.map((allTransaction) => (
                  <React.Fragment>
                    {allTransaction.source === uid &&
                    allTransaction.destination === fid ? (
                      <React.Fragment>
                        <Typography variant="h6" gutterBottom component="div">
                          You charged{" "}
                          {changeUidintoUsername(allTransaction.destination)}{" "}
                          for {allTransaction.amount} in{" "}
                          {allTransaction.currency}.
                        </Typography>
                        <div className="optionContainer">
                          <span className="detailsBtn">
                            <Chip
                              label="Details"
                              onClick={() =>
                                handleShowDetails(allTransaction, 0)
                              }
                              icon={<SearchIcon />}
                              color="secondary"
                            />
                          </span>
                          <span className="status">
                            {allTransaction.status === "unpaid" ? (
                              <Chip color="error" label="Unpaid" />
                            ) : (
                              <Chip color="success" label="Paid" />
                            )}
                          </span>
                        </div>
                        <Divider sx={{ marginTop: "10px" }} />
                      </React.Fragment>
                    ) : allTransaction.source === fid &&
                      allTransaction.destination === uid ? (
                      <React.Fragment>
                        <Typography variant="h6" gutterBottom component="div">
                          You owe {changeUidintoUsername(allTransaction.source)}{" "}
                          for {allTransaction.amount} in{" "}
                          {allTransaction.currency}.
                        </Typography>
                        <div className="optionContainer">
                          <span className="detailsBtn">
                            <Chip
                              label="Details"
                              onClick={() =>
                                handleShowDetails(allTransaction, 1)
                              }
                              icon={<SearchIcon />}
                              color="secondary"
                            />
                          </span>
                          <span className="status">
                            {allTransaction.status === "unpaid" ? (
                              <React.Fragment>
                                <Chip color="error" label="Unpaid" />
                                <span className="payBtn">
                                  <Chip
                                    label="Pay now"
                                    onClick={() =>
                                      handlePaymentConfirm(allTransaction)
                                    }
                                    icon={<MonetizationOnIcon />}
                                    color="primary"
                                  />
                                </span>
                              </React.Fragment>
                            ) : (
                              <Chip color="success" label="Paid" />
                            )}
                          </span>
                        </div>
                        <Divider sx={{ marginTop: "10px" }} />
                      </React.Fragment>
                    ) : (
                      <React.Fragment></React.Fragment>
                    )}
                  </React.Fragment>
                ))}
              </div>
            ) : (
              <>You don't have any transactions yet.</>
            )}
          </FormControl>
        </div>
      </React.Fragment>
    );
  };
  const handleFriendSelect = (friend) => {
    console.log("select a friend");
    console.log(friend);
    setFriendDetails(friend);
    setFriendSelected(true);
    if (groupSelected) setGroupSelected(false);
    setGroupDetails(null);
  };
  const handleGroupSelect = (group) => {
    console.log("select a group");
    console.log(group);
    setGroupDetails(group);
    setGroupSelected(true);
    if (friendSelected) setFriendSelected(false);
    setFriendDetails(null);
  };
  return (
    <div>
      <Header />
      <div className="container">
        <div className="board">
          <div className="left">
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <TabList
                  sx={{ height: 70 }}
                  onChange={handleChange}
                  aria-label="switch-bar"
                  variant="fullWidth"
                  centered
                >
                  <Tab sx={{ height: 70 }} label="Friends" value="1" />
                  <Tab sx={{ height: 70 }} label="Groups" value="2" />
                </TabList>
              </Box>
              {value === "1" ? (
                <Paper
                  component="form"
                  sx={{
                    p: "2px 4px",
                    display: "flex",
                    alignItems: "center",
                    width: "fullWidth",
                    marginLeft: "8px",
                    marginRight: "8px",
                    marginTop: "15px",
                    marginBottom: "15px",
                  }}
                >
                  <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder="Add a Friend"
                    inputProps={{ "aria-label": "search-items" }}
                    onChange={(e) => (usernameInput = e.target.value)}
                  />
                  <IconButton
                    sx={{ p: "10px" }}
                    aria-label="search"
                    onClick={userNameInputHandler}
                  >
                    <AddCircleOutlineIcon />
                  </IconButton>
                </Paper>
              ) : (
                <></>
              )}

              {value === "1" ? (
                <TabPanel value="1" className="friendsTab">
                  <div className="friendsList">
                    {friendsList &&
                    friendsList.friendList &&
                    friendsList.friendList.length !== 0 ? (
                      <React.Fragment>
                        {friendsList.friendList.map((friend) => (
                          <div key={friend.uid} className="friendWrapper">
                            <PopupState variant="popover" popId="popupMenu">
                              {(popupState) => (
                                <div className="friend">
                                  <Button
                                    {...bindTrigger(popupState)}
                                    size="small"
                                    startIcon={
                                      <Avatar className="avatar">
                                        {friend.firstname[0].toUpperCase()}
                                        {friend.lastname[0].toUpperCase()}
                                      </Avatar>
                                    }
                                  >
                                    {friend.firstname + " " + friend.lastname}
                                  </Button>
                                  <div className="buttonGroup">
                                    <IconButton
                                      className="createTransactionBtn"
                                      color="inherit"
                                      size="small"
                                      onClick={() =>
                                        handleCreateTransaction(uid, friend)
                                      }
                                    >
                                      <AddCircleOutlineIcon />
                                    </IconButton>
                                    <IconButton
                                      className="deleteFriendBtn"
                                      color="inherit"
                                      size="small"
                                      onClick={() =>
                                        handleDelete(
                                          uid,
                                          friend.uid,
                                          friend.firstname,
                                          friend.lastname
                                        )
                                      }
                                    >
                                      <HighlightOffIcon />
                                    </IconButton>
                                  </div>
                                  <Menu {...bindMenu(popupState)}>
                                    <MenuItem
                                      onClick={() =>
                                        handleViewHistory(uid, friend.uid)
                                      }
                                    >
                                      View History
                                    </MenuItem>
                                    <MenuItem
                                      onClick={() => handleFriendSelect(friend)}
                                    >
                                      Chat
                                    </MenuItem>
                                  </Menu>
                                </div>
                              )}
                            </PopupState>
                          </div>
                        ))}
                      </React.Fragment>
                    ) : (
                      <>You haven't added any friends yet.</>
                    )}
                  </div>
                  <div className="applicationIcon">
                    {applicationList && applicationList.length !== 0 ? (
                      <IconButton
                        aria-label="friendsRequest"
                        onClick={pendingApplication}
                      >
                        <StyledBadge
                          badgeContent={applicationList.length}
                          color="secondary"
                        >
                          <GroupAddIcon />
                        </StyledBadge>
                      </IconButton>
                    ) : (
                      <>No Pending Friend Application</>
                    )}
                  </div>
                </TabPanel>
              ) : (
                <TabPanel value="2" className="groupTab">
                  <div className="groupList">
                    {groupList && groupList.length !== 0 ? (
                      <React.Fragment>
                        {groupList.map((group) => (
                          <React.Fragment key={group.gid}>
                            {group.status === "valid" ? (
                              <div>
                                <PopupState
                                  variant="popover"
                                  popupId="demo-popup-menu"
                                >
                                  {(popupState) => (
                                    <div className="groupWrapper">
                                      <Button
                                        {...bindTrigger(popupState)}
                                        startIcon={
                                          <Avatar className="avatar">
                                            {group.groupname[0].toUpperCase()}
                                          </Avatar>
                                        }
                                        className="group"
                                      >
                                        {group.groupname}
                                      </Button>
                                      {/* <div
                                        {...bindTrigger(popupState)}
                                        sx={{ width: 200 }}
                                        className="group"
                                      >
                                        <Avatar className="avatar">
                                          {group.groupname[0].toUpperCase()}
                                        </Avatar>
                                        <Typography
                                          variant="overline"
                                          display="block"
                                          gutterBottom
                                        >
                                          {group.groupname}
                                        </Typography>
                                      </div> */}
                                      <Menu {...bindMenu(popupState)}>
                                        <MenuItem
                                          onClick={() =>
                                            handleInvite(
                                              uid,
                                              group.groupname,
                                              group.gid
                                            )
                                          }
                                        >
                                          Invite Friends
                                        </MenuItem>
                                        <MenuItem
                                          onClick={() =>
                                            handleGroupSelect(group)
                                          }
                                        >
                                          Chat
                                        </MenuItem>
                                        <MenuItem
                                          onClick={() =>
                                            handleCheckQuit(
                                              group.gid,
                                              uid,
                                              group.groupname
                                            )
                                          }
                                        >
                                          Quit
                                        </MenuItem>
                                      </Menu>
                                    </div>
                                  )}
                                </PopupState>
                              </div>
                            ) : (
                              <React.Fragment></React.Fragment>
                            )}
                            <Divider />
                          </React.Fragment>
                        ))}
                      </React.Fragment>
                    ) : (
                      <>You haven't added any group yet.</>
                    )}
                  </div>
                  <div className="addGroup">
                    <Button
                      sx={{ height: 50, width: 290 }}
                      variant="outlined"
                      onClick={() => handleAddGroup(uid)}
                    >
                      <AddCircleOutlineIcon />
                    </Button>
                  </div>
                </TabPanel>
              )}
            </TabContext>
          </div>
          <div className="right">
            <AppBar sx={{ height: 70 }} position="static" color="transparent">
              <Toolbar className="dashboardBar">
                <Button variant="outlined" onClick={viewTotalBalance}>
                  Total Balance
                </Button>

                <Box className="profile">
                  {friendsList && friendsList.user
                    ? "Hi, " + friendsList.user.username
                    : ""}

                  <IconButton
                    size="large"
                    aria-label="account of current user"
                    aria-controls="menu-appbar"
                    aria-haspopup="true"
                    onClick={handleMenu}
                    color="inherit"
                  >
                    <AccountCircle />
                  </IconButton>
                  <Menu
                    id="menu-appbar"
                    anchorEl={anchorEl}
                    anchorOrigin={{
                      vertical: "top",
                      horizontal: "right",
                    }}
                    keepMounted
                    transformOrigin={{
                      vertical: "top",
                      horizontal: "right",
                    }}
                    open={Boolean(anchorEl)}
                    onClose={tmpHandler}
                  >
                    <MenuItem onClick={tmpHandler}>Profile</MenuItem>
                    <MenuItem onClick={handleShowAllTransaction}>
                      History
                    </MenuItem>
                    <MenuItem onClick={tmpHandler}>Deactivate Account</MenuItem>
                    <MenuItem onClick={handleFAQ}>FAQ</MenuItem>
                    <MenuItem onClick={handleLogout}>Logout</MenuItem>
                  </Menu>
                </Box>
              </Toolbar>
            </AppBar>
            {friendSelected || groupSelected ? (
              <ChatPanel
                uid={uid}
                friend={friendDetails}
                group={groupDetails}
                transactions={allTransactionList}
                dialogOpen={dialogOpen}
                groupMode={friendSelected ? false : true}
              />
            ) : (
              <></>
            )}
          </div>
        </div>
      </div>
      <Dialog open={dialogOpen} onClose={() => setDialog(false)}>
        <DialogTitle id="dialog-title">{dialogTitle}</DialogTitle>
        <DialogContent>
          <DialogContentText>{dialogContent}</DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dashboard;
