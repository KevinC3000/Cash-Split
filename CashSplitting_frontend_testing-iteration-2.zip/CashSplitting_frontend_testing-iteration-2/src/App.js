import React, { useState } from "react";
import './App.css';
import Auth from "./components/Auth";
import DashBoard from "./components/Dashboard";

function App() {
  const[token, setToken] = useState(undefined);
  const[uid, setUserID] = useState(undefined);
  if(!token){
    return (
      <Auth 
        setToken={setToken}
        setUserID={setUserID}
      />
    );
  }
  return (
    <div className="App">
      <DashBoard uid={uid} setToken={setToken} />
    </div>
  )
}

export default App;
