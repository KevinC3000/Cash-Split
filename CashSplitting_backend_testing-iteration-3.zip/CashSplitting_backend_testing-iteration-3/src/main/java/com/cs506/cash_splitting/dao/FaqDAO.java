package com.cs506.cash_splitting.dao;

public interface FaqDAO {
    Object getAllFaq();
}
