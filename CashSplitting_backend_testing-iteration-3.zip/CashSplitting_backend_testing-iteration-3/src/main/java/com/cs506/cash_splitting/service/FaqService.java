package com.cs506.cash_splitting.service;

public interface FaqService {
    public Object getAllFaq();
}
